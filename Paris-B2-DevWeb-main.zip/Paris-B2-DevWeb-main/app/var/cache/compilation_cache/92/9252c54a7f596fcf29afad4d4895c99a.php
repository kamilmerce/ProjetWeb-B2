<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* register.html.twig */
class __TwigTemplate_0f5d133dec4abe7522e07d7703b7a89e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base_auth.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base_auth.html.twig", "register.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <h1>Créez votre compte</h1>

    <form action=\"\" method=\"post\">

        <div>

            <label for=\"email\">Email</label>
            <input type=\"email\" 
                name=\"email\" 
                
                id=\"email\" 
                placeholder=\"Entrez votre email\"
            />
        </div>

        <div>
        <label for \"email_cfg\">Email confirmation</label>
        <input
            type=\"email\"
            name=\"email_cfg\"
            id=\"email_cfg\"
            placeholder=\"Confirmez votre email\"
        />
        </div>

        <div>

            <label for=\"password\">Mot de passe</label>
            <input type=\"password\" 
                name=\"password\" 
                id=\"password\" 
                placeholder=\"Entrez votre mot de passe\"
            />
        </div>

        <div>
        <label for \"password_cfg\">Mot de passe confirmation</label>
        <input
            type=\"password\"
            name=\"password_cfg\"
            id=\"password_cfg\"
            placeholder=\"Confirmez votre mot de passe\"
        />
        </div>

        <div>
            <input type=\"Submit\" name=\"send\" value=\"Créez le compte\"/>
        </div>

    </form>

    <p>
        <a href=\"index.php\">Dèja un compte ?</a>

    </p>
";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "register.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base_auth.html.twig\" %}

{% block body %}
    <h1>Créez votre compte</h1>

    <form action=\"\" method=\"post\">

        <div>

            <label for=\"email\">Email</label>
            <input type=\"email\" 
                name=\"email\" 
                
                id=\"email\" 
                placeholder=\"Entrez votre email\"
            />
        </div>

        <div>
        <label for \"email_cfg\">Email confirmation</label>
        <input
            type=\"email\"
            name=\"email_cfg\"
            id=\"email_cfg\"
            placeholder=\"Confirmez votre email\"
        />
        </div>

        <div>

            <label for=\"password\">Mot de passe</label>
            <input type=\"password\" 
                name=\"password\" 
                id=\"password\" 
                placeholder=\"Entrez votre mot de passe\"
            />
        </div>

        <div>
        <label for \"password_cfg\">Mot de passe confirmation</label>
        <input
            type=\"password\"
            name=\"password_cfg\"
            id=\"password_cfg\"
            placeholder=\"Confirmez votre mot de passe\"
        />
        </div>

        <div>
            <input type=\"Submit\" name=\"send\" value=\"Créez le compte\"/>
        </div>

    </form>

    <p>
        <a href=\"index.php\">Dèja un compte ?</a>

    </p>
{% endblock %}", "register.html.twig", "/var/www/templates/register.html.twig");
    }
}
