<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.html.twig */
class __TwigTemplate_e4b1419f7f442d55e4cbd9990abc33c1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base_auth.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base_auth.html.twig", "index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <h1>Connexion</h1>

    ";
        // line 6
        if (($context["msg"] ?? null)) {
            // line 7
            echo "        <div>";
            echo twig_escape_filter($this->env, ($context["msg"] ?? null), "html", null, true);
            echo "</div>
    ";
        }
        // line 9
        echo "
    <form action=\"\" method=\"post\">

        <div>

            <label for=\"email\">Email</label>
            <input type=\"email\" 
                name=\"email\" 
                
                id=\"email\" 
                placeholder=\"Entrez votre email\"
            />
        </div>

        <div>

            <label for=\"password\">Mot de passe</label>
            <input type=\"password\" 
                name=\"password\" 
                id=\"password\" 
                placeholder=\"Entrez votre mot de passe\"
            />
        </div>

        <div>
            <input type=\"Submit\" name=\"send\" value=\"Connexion\"/>
        </div>

    </form>

    <p>
        <a href=\"register.php\">Pas encore de compte ?</a>
    </p>
";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  62 => 9,  56 => 7,  54 => 6,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base_auth.html.twig\" %}

{% block body %}
    <h1>Connexion</h1>

    {% if msg %}
        <div>{{msg}}</div>
    {% endif %}

    <form action=\"\" method=\"post\">

        <div>

            <label for=\"email\">Email</label>
            <input type=\"email\" 
                name=\"email\" 
                
                id=\"email\" 
                placeholder=\"Entrez votre email\"
            />
        </div>

        <div>

            <label for=\"password\">Mot de passe</label>
            <input type=\"password\" 
                name=\"password\" 
                id=\"password\" 
                placeholder=\"Entrez votre mot de passe\"
            />
        </div>

        <div>
            <input type=\"Submit\" name=\"send\" value=\"Connexion\"/>
        </div>

    </form>

    <p>
        <a href=\"register.php\">Pas encore de compte ?</a>
    </p>
{% endblock %}", "index.html.twig", "/var/www/templates/index.html.twig");
    }
}
